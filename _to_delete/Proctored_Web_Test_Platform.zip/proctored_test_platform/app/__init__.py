"""Proctored web test platform."""
